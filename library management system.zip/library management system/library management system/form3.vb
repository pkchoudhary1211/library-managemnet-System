﻿Public Class Form3

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Hide()

        Form2.Show()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Clear()
        MaskedTextBox1.Clear()
        MaskedTextBox2.Clear()
        TextBox3.Clear()
        MaskedTextBox1.Clear()

    End Sub

    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = "Book Issue"
        Me.MaximizeBox = False
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.Fixed3D
        Me.TopMost = True

    End Sub

    Private Sub ReturnBookToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReturnBookToolStripMenuItem.Click
        Me.Hide()
        Form4.Show()

    End Sub

    Private Sub DisplayToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DisplayToolStripMenuItem.Click
        Me.Hide()
        Form5.Show()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub AddNewBookToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddNewBookToolStripMenuItem.Click
        Me.Hide()
        Form6.Show()
    End Sub

    Private Sub ReadersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReadersToolStripMenuItem.Click
        Me.Hide()
        Form8.Show()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If MaskedTextBox1.Text = "" Or TextBox1.Text = "" Or MaskedTextBox2.Text = "" Or TextBox3.Text = "" Then
            MsgBox("Fill all credentials!", MsgBoxStyle.Exclamation)

        Else
            MsgBox("Data Save Sucessfully ", MsgBoxStyle.Information)
            TextBox1.Clear()
            MaskedTextBox1.Clear()
            MaskedTextBox2.Clear()
            TextBox3.Clear()
            MaskedTextBox1.Clear()
        End If


    End Sub

    Private Sub MaskedTextBox2_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles MaskedTextBox2.MaskInputRejected

    End Sub
End Class